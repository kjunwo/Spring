package com.dw.jpaapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaappApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaappApplication.class, args);
	}

}
