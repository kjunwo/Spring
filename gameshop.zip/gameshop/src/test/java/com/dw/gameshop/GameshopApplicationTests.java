package com.dw.gameshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
