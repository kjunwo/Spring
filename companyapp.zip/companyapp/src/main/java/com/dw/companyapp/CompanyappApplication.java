package com.dw.companyapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompanyappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompanyappApplication.class, args);
	}

}
