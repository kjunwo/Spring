package com.dw.companyapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyappApplicationTests {

	@Test
	void contextLoads() {
	}

}
